"""All console rendering."""
