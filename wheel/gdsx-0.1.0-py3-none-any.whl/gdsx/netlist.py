"""Turn traced connectivity into a named netlist and emit it"""

from __future__ import annotations
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Callable

from .connectivity import Connectivity, trace
from .core.netlist import Instance, Netlist  # noqa: F401  (re-exported)
from .functions import generic_name, lookup
from .geo import types as g
from .loader import Design
from .pins import PinOracle, abstract_shapes, bond_pins, direction_of

Progress = Callable[[str, int, int], None]


def _placement_key(item: tuple[str, object]) -> tuple:
    """Canonical placement order: cell name, then position, then orientation.

    Net numbering and instance numbering both hang off this, so it lives in
    one place rather than being spelled out at each call site.
    """
    return (item[0], item[1].disp.y, item[1].disp.x, str(item[1]))


def named_placements(design: Design) -> list[tuple[str, object, str]]:
    """Every placement in canonical order, each with the name it is known by.

    The name is the cell's short name plus a per-cell-name occurrence
    counter, e.g. `dfrtp_2_4`. `build_with_net_ids` uses it for the netlist's
    logic instances; `render.py` uses it to say which cell a piece of
    intra-cell metal belongs to, and that includes the fill, tap and decap
    cells the netlist leaves out. Counters are per cell name, so numbering a
    non-logic cell here cannot shift a logic cell's number.
    """
    counters: dict[str, int] = defaultdict(int)
    out: list[tuple[str, object, str]] = []
    for cell_name, trans in sorted(design.instances(), key=_placement_key):
        counters[cell_name] += 1
        short = cell_name.split("__", 1)[-1]
        out.append((cell_name, trans, f"{short}_{counters[cell_name]}"))
    return out


def _is_driven(nl: Netlist, net: str) -> bool:
    """True if any cell output pin sits on this net"""
    cells = {inst.name: inst.cell for inst in nl.instances}
    for ref in nl.nets[net]:
        inst, pin = ref.split("/")
        if direction_of(cells[inst], pin) == "output":
            return True
    return False


def trace_design(
    design: Design,
    macros: dict | None = None,
    oracle: PinOracle | None = None,
    *,
    progress: Progress | None = None,
) -> Connectivity:
    """Trace connectivity the same way `build` does, for callers that need the
    raw `Connectivity` rather than a named `Netlist` -- `render.py` is one,
    so its shapes land on the same net numbering the netlist does.

    `progress`, if given, is passed on to `connectivity.trace` (stages
    "trace", "vias") and then reported once more for pin bonding (stage
    "bond_pins").
    """
    if oracle is None:
        oracle = PinOracle(design, macros)
    conn = trace(design, abstract_shapes(design, oracle), progress=progress)
    bond_pins(design, conn, oracle)
    if progress is not None:
        progress("bond_pins", 1, 1)
    return conn


def build(
    design: Design,
    conn: Connectivity | None = None,
    macros: dict | None = None,
    *,
    progress: Progress | None = None,
) -> Netlist:
    """Resolve every instance pin to a net and name the result"""
    nl, _ = build_with_net_ids(design, conn, macros, progress=progress)
    return nl


# how often the "resolve" stage reports back, in instances
_RESOLVE_CHUNK = 50


def build_with_net_ids(
    design: Design,
    conn: Connectivity | None = None,
    macros: dict | None = None,
    *,
    progress: Progress | None = None,
) -> tuple[Netlist, dict[int, str]]:
    """`build`, also returning the net id -> name mapping it used internally

    `render.py` needs this: it works from the same `Connectivity` (so its
    shape-to-net lookups land on the same integer ids this function assigns),
    and has to turn those ids back into the names the netlist browser shows.

    `progress`, if given, is called as `(stage, done, total)` through tracing
    ("trace", "vias", "bond_pins", see `trace_design`), then during pin
    resolution ("resolve", one report per `_RESOLVE_CHUNK` instances) and
    once for naming ("name").
    """
    tech = design.tech
    oracle = PinOracle(design, macros)
    if conn is None:
        conn = trace_design(design, macros, oracle, progress=progress)

    nl = Netlist(top=design.top)

    #  collect pin -> net id, keeping instances in a stable placement order
    # A pin often carries several labels, so collect refs in a set, one entry
    # per instance pin
    members: dict[int, set[str]] = defaultdict(set)
    placements = named_placements(design)

    for i, (cell_name, trans, inst_name) in enumerate(placements):
        if progress is not None and i % _RESOLVE_CHUNK == 0:
            progress("resolve", i, len(placements))
        if not tech.is_logic_cell(cell_name):
            continue
        inst = Instance(name=inst_name, cell=cell_name)

        by_pin: dict[str, set[int]] = defaultdict(set)
        for pin in oracle.pins(cell_name):
            net_id = conn.net_at(pin.layer, trans * pin.point)
            if net_id is not None:
                by_pin[pin.name].add(net_id)

        for pin_name in sorted({p.name for p in oracle.pins(cell_name)}):
            ref = f"{inst.name}/{pin_name}"
            found = by_pin.get(pin_name)
            if not found:
                nl.floating.append(ref)
                continue
            if len(found) > 1:
                # Labels for one pin landed on different nets, so either the cell
                # is genuinely shorted or tracing lost a connection
                nl.conflicts.append(ref)
            net_id = min(found)
            inst.connections[pin_name] = net_id  # provisional: id, renamed below
            members[net_id].add(ref)
        nl.instances.append(inst)
    if progress is not None:
        progress("resolve", len(placements), len(placements))

    # naming: top-level labels preserved, everything else gets n<id>
    labels = _top_labels(design, conn)
    names = _name_nets(labels, members)
    if progress is not None:
        progress("name", 1, 1)

    for inst in nl.instances:
        inst.connections = {p: names[i] for p, i in inst.connections.items()}
    nl.nets = {names[i]: sorted(refs) for i, refs in members.items()}
    nl.power_nets = {names[i] for i in members if names[i] in tech.power_pins}

    # A labelled net reaches the outside world, so it is a port
    for net_id in labels:
        net = names[net_id]
        if net in nl.power_nets or net not in nl.nets:
            continue
        nl.ports[net] = "output" if _is_driven(nl, net) else "input"

    return nl, names


def _top_labels(design: Design, conn: Connectivity) -> dict[int, set[str]]:
    """Text labels placed at the top level, resolved to the net they sit on"""
    labels: dict[int, set[str]] = defaultdict(set)
    for rl in design.tech.routing:
        idx = design.index_of(rl.pin)
        if idx is None:
            continue
        for shape in design.layout.shapes(design.top, idx):
            if not isinstance(shape, g.Text):
                continue
            net_id = conn.net_at(rl.name, shape.point)
            if net_id is not None:
                labels[net_id].add(shape.string)
    return labels


def _name_nets(
    labels: dict[int, set[str]], members: dict[int, list[str]]
) -> dict[int, str]:
    names: dict[int, str] = {}
    taken: set[str] = set()
    for net_id in sorted(set(members) | set(labels)):
        candidates = sorted(labels.get(net_id, ()))
        name = candidates[0] if candidates else f"n{net_id}"
        while name in taken:
            name += "_"
        taken.add(name)
        names[net_id] = name
    return names


# emitters
_VALID = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*\Z")


def ident(name: str) -> str:
    """Verilog identifier for a net name

    Layout labels are not constrained to Verilog syntax so anything irregular
    becomes an escaped identifier
    """
    return name if _VALID.match(name) else f"\\{name} "


def to_json(nl: Netlist) -> str:
    return json.dumps(nl.to_dict(), indent=2)


def naming_digest(nl: Netlist) -> str:
    """A hash over every name extraction invents, in a fixed order

    The contract `tests/test_naming_stable.py` freezes and `gdsx puzzle
    verify` checks a fresh extraction against: instance placement order, nets
    sorted by name, ports sorted by name. Two netlists with this digest equal
    named every instance, net and port identically.
    """
    lines = [f"top {nl.top}"]
    lines += [f"inst {i.name} {i.cell}" for i in nl.instances]  # placement order
    lines += [f"net {n}" for n in sorted(nl.nets)]
    lines += [f"port {n} {d}" for n, d in sorted(nl.ports.items())]
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()


def to_generic_dict(nl: Netlist) -> dict:
    """Like `Netlist.to_dict`, but with library cells replaced by generic primitives

    Same instance names and net names, so this stays diffable against the
    sky130 JSON. Cells the library doesn't describe are dropped, same as
    `to_generic_verilog`.
    """
    d = nl.to_dict()
    instances = []
    for inst in nl.instances:
        cell = lookup(inst.cell)
        if cell is None:
            continue
        pins = list(cell.inputs) + list(cell.outputs)
        connections = {p: n for p, n in inst.connections.items() if p in pins}
        instances.append(
            {
                "name": inst.name,
                "cell": generic_name(inst.cell),
                "connections": connections,
            }
        )
    d["instances"] = instances
    return d


def to_generic_json(nl: Netlist) -> str:
    return json.dumps(to_generic_dict(nl), indent=2)


def to_verilog(nl: Netlist) -> str:
    ports = sorted(nl.ports)
    lines = [
        "// generated by gdsx",
        f"module {nl.top} ({', '.join(ident(p) for p in ports)});",
    ]
    for p in ports:
        lines.append(f"  {nl.ports[p]} {ident(p)};")
    wires = sorted(set(nl.nets) - set(ports) - nl.power_nets)
    for chunk in _chunks([ident(w) for w in wires], 8):
        lines.append("  wire " + ", ".join(chunk) + ";")
    for net in sorted(nl.power_nets):
        lines.append(
            f"  {'supply0' if net.endswith('GND') else 'supply1'} {ident(net)};"
        )
    lines.append("")
    for inst in nl.instances:
        conns = ", ".join(
            f".{p}({ident(n)})" for p, n in sorted(inst.connections.items())
        )
        lines.append(f"  {inst.cell} {inst.name} ({conns});")
    lines += ["", "endmodule", ""]
    return "\n".join(lines)


def to_generic_verilog(nl: Netlist) -> str:
    """The same netlist with the library cells replaced by generic primitives"""
    ports = sorted(nl.ports)
    lines = [
        "// generated by gdsx: technology-independent view",
        f"module {nl.top} ({', '.join(ident(p) for p in ports)});",
    ]
    for p in ports:
        lines.append(f"  {nl.ports[p]} {ident(p)};")
    wires = sorted(set(nl.nets) - set(ports) - nl.power_nets)
    for chunk in _chunks([ident(w) for w in wires], 8):
        lines.append("  wire " + ", ".join(chunk) + ";")
    lines.append("")
    for inst in nl.instances:
        cell = lookup(inst.cell)
        if cell is None:
            lines.append(f"  // no library description for {inst.cell} ({inst.name})")
            continue
        pins = [
            p for p in list(cell.inputs) + list(cell.outputs) if p in inst.connections
        ]
        conns = ", ".join(f".{p}({ident(inst.connections[p])})" for p in pins)
        lines.append(f"  {generic_name(inst.cell)} {inst.name} ({conns});")
    lines += ["", "endmodule", ""]
    return "\n".join(lines)


def to_cone_verilog(
    nl: Netlist,
    name: str,
    instances: set[str],
    rename: dict[str, str],
    outputs: list[str],
) -> str:
    """Emit part of the netlist as a standalone module, for proving in isolation

    `rename` maps boundary nets (register outputs, control signals) to the port
    names the reference model uses, so a miter can match the two by name. Any
    net the cone reads but does not drive becomes an input
    """
    chosen = [inst for inst in nl.instances if inst.name in instances]
    driven, read = set(), set()
    for inst in chosen:
        cell = lookup(inst.cell)
        if cell is None:
            continue
        driven |= {inst.connections[p] for p in cell.functions if p in inst.connections}
        read |= {inst.connections[p] for p in cell.inputs if p in inst.connections}

    port = lambda net: rename.get(net, net)  # noqa: E731
    inputs = sorted(port(n) for n in read - driven - nl.power_nets)
    out_ports = [port(n) for n in outputs]
    internal = sorted({port(n) for n in driven} - set(out_ports))

    lines = [f"module {name} ({', '.join(inputs + out_ports)});"]
    if inputs:
        lines.append(f"  input {', '.join(inputs)};")
    lines.append(f"  output {', '.join(out_ports)};")
    for chunk in _chunks(internal, 8):
        lines.append("  wire " + ", ".join(chunk) + ";")
    lines.append("")
    for inst in chosen:
        cell = lookup(inst.cell)
        pins = [
            p for p in list(cell.inputs) + list(cell.outputs) if p in inst.connections
        ]
        conns = ", ".join(f".{p}({port(inst.connections[p])})" for p in pins)
        lines.append(f"  {generic_name(inst.cell)} {inst.name} ({conns});")
    lines += ["", "endmodule", ""]
    return "\n".join(lines)


def to_dot(nl: Netlist) -> str:
    cells = {inst.name: inst.cell for inst in nl.instances}
    lines = ["digraph netlist {", "  rankdir=LR;", "  node [shape=box];"]
    for inst in nl.instances:
        lines.append(
            f'  "{inst.name}" [label="{inst.name}\\n{inst.cell.split("__")[1]}"];'
        )
    for net, refs in sorted(nl.nets.items()):
        if net in nl.power_nets:
            continue
        lines.append(f'  "{net}" [shape=ellipse, style=dashed];')
        for ref in refs:
            inst, pin = ref.split("/")
            if direction_of(cells[inst], pin) == "output":
                lines.append(f'  "{inst}" -> "{net}" [label="{pin}"];')
            else:
                lines.append(f'  "{net}" -> "{inst}" [label="{pin}"];')
    lines.append("}")
    return "\n".join(lines)


def _chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i : i + n]


def write_all(nl: Netlist, outdir: Path) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    written = []
    outputs = (
        ("json", to_json(nl)),
        ("v", to_verilog(nl)),
        ("generic.v", to_generic_verilog(nl)),
        ("generic.json", to_generic_json(nl)),
        ("dot", to_dot(nl)),
    )
    for suffix, text in outputs:
        path = outdir / f"{nl.top}.{suffix}"
        path.write_text(text)
        written.append(path)
    return written
